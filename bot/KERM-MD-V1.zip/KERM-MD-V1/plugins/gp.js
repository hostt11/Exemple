const config = require('../config');
const { cmd, commands } = require('../command');
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson } = require('../lib/functions');

// Commande pour voir les demandes d'adhésion en attente
cmd({
    pattern: "joinrequests",
    desc: "Get list of participants who requested to join the group",
    react: "📋",
    category: "group",
    filename: __filename
}, async (client, message, context, { from, q, reply, isGroup }) => {
    if (!isGroup) return reply("This command can only be used in a group chat.");
    
    try {
        const groupId = from;
        console.log("Attempting to fetch pending requests for group: " + groupId);
        const requests = await client.groupRequestParticipantsList(groupId);
        console.log(requests);
        
        if (requests.length > 0) {
            let requestText = 'Pending Requests to Join the Group:\n';
            let mentions = [];
            
            requests.forEach(request => {
                const jid = request.jid;
                requestText += "😻 @" + jid.split('@')[0] + '\n';
                mentions.push(jid);
            });
            
            const messageOptions = { 'text': requestText, 'mentions': mentions };
            await client.sendMessage(from, messageOptions);
        } else {
            reply("No pending requests to join the group.");
        }
    } catch (error) {
        console.error("Error fetching participant requests: " + error.message);
        reply("⚠️ An error occurred while fetching the pending requests. Please try again later.");
    }
});

// Commande pour approuver/rejeter toutes les demandes d'adhésion
cmd({
    pattern: "allreq",
    desc: "Approve or reject all join requests",
    react: "✅",
    category: "group",
    filename: __filename
}, async (client, message, context, { from, reply, isGroup }) => {
    if (!isGroup) return reply("This command can only be used in a group chat.");
    
    const action = context.args[0]?.includes("approve") ? "approve" : "reject";
    
    try {
        const requests = await client.groupRequestParticipantsList(from);
        if (requests.length === 0) return reply("There are no pending requests to manage.");
        
        let requestList = "Pending Requests to Join the Group:\n";
        let mentionList = [];
        let jidList = [];
        
        requests.forEach(request => {
            const jid = request.jid;
            requestList += "😻 @" + jid.split('@')[0] + '\n';
            mentionList.push(jid);
            jidList.push(jid);
        });
        
        const messageOptions = { 'text': requestList, 'mentions': mentionList };
        await client.sendMessage(from, messageOptions);
        
        const result = await client.groupRequestParticipantsUpdate(from, jidList, action);
        console.log(result);
        reply("Successfully " + action + "ed all join requests.");
    } catch (error) {
        console.error("Error updating participant requests: " + error.message);
        reply("⚠️ An error occurred while processing the request. Please try again later.");
    }
});

// Constantes pour les messages éphémères
const WA_DEFAULT_EPHEMERAL_24H = 86400; // 24h en secondes
const WA_DEFAULT_EPHEMERAL_7D = 604800;  // 7 jours en secondes
const WA_DEFAULT_EPHEMERAL_90D = 7776000; // 90 jours en secondes

// Commande pour activer/désactiver les messages éphémères
cmd({
    pattern: "ephemeral",
    react: "🌪️",
    alias: ["dm"],
    desc: "Turn on/off disappearing messages.",
    category: "main",
    filename: __filename
}, async (client, message, context, { from, isGroup, isAdmins, args }) => {
    if (!isGroup) {
        await client.sendMessage(from, { text: "This command can only be used in groups." });
        return;
    }
    
    if (!isAdmins) {
        await client.sendMessage(from, { text: "Only admins can turn on/off ephemeral messages." });
        return;
    }
    
    const setting = args[0];
    
    if (setting === 'on') {
        const duration = args[1];
        let expirationTime;
        
        switch (duration) {
            case '24h':
                expirationTime = WA_DEFAULT_EPHEMERAL_24H;
                break;
            case '7d':
                expirationTime = WA_DEFAULT_EPHEMERAL_7D;
                break;
            case '90d':
                expirationTime = WA_DEFAULT_EPHEMERAL_90D;
                break;
            default:
                await client.sendMessage(from, { text: "Invalid duration! Use `24h`, `7d`, or `90d`." });
                return;
        }
        
        await client.sendMessage(from, { disappearingMessagesInChat: expirationTime });
        await client.sendMessage(from, { text: 'ephemeral messages are now ON for ' + duration + '.' });
    } else if (setting === 'off') {
        await client.sendMessage(from, { disappearingMessagesInChat: false });
        await client.sendMessage(from, { text: 'ephemeral messages are now OFF.' });
    } else {
        await client.sendMessage(from, { text: 'Please use `!ephemeral on <duration>` or `!ephemeral off`.' });
    }
});

// Commande pour envoyer un message privé (DM)
cmd({
    pattern: "senddm",
    react: "🌪️",
    alias: ["dm"],
    desc: "Send a disappearing message.",
    category: "main",
    filename: __filename
}, async (client, message, context, { from, isGroup, isAdmins, args }) => {
    if (!isGroup) {
        await client.sendMessage(from, { text: "This command can only be used in groups." });
        return;
    }
    
    if (!args.length) {
        await client.sendMessage(from, { text: "Please provide a message." });
        return;
    }
    
    const messageText = args.join(' ');
    const messageOptions = { text: messageText };
    const ephemeralOptions = { ephemeralExpiration: WA_DEFAULT_EPHEMERAL_7D };
    
    await client.sendMessage(from, messageOptions, ephemeralOptions);
});

// Commande pour fermer le groupe (seuls les admins peuvent parler)
cmd({
    pattern: "mute",
    react: "🔇",
    alias: ["close", "lockgc"],
    desc: "Change to group settings to only admins can send messages.",
    category: "group",
    use: ".mute",
    filename: __filename
}, async (client, message, context, { from, isGroup, sender, isOwner, groupAdmins, isBotAdmins, isAdmins, reply, pushname }) => {
    try {
        if (!isGroup) return reply("*❌ This command can only be used in groups.*");
        if (!isOwner && !isAdmins) return reply("*⚠️ Only group admins or the bot owner can use this command.*");
        if (!isBotAdmins) return reply("*❌ The bot needs admin rights to execute this command.*");
        
        await client.groupSettingUpdate(from, 'announcement');
        
        const response = { text: '*✅ The group has been closed by ' + pushname + '.* 🔇' };
        await client.sendMessage(from, response, { 'quoted': message });
    } catch (error) {
        console.log(error);
        reply("❌ *Error occurred !!*\n\n" + error);
    }
});

// Commande pour ouvrir le groupe (tous les membres peuvent parler)
cmd({
    pattern: "unmute",
    react: "🔇",
    alias: ["open", "unlockgc"],
    desc: "Change group settings so all members can send messages.",
    category: "group",
    use: ".unmute",
    filename: __filename
}, async (client, message, context, { from, isGroup, sender, isOwner, groupAdmins, isBotAdmins, isAdmins, reply, pushname }) => {
    try {
        if (!isGroup) return reply("*❌ This command can only be used in groups.*");
        if (!isOwner && !isAdmins) return reply("*⚠️ Only group admins or the bot owner can use this command.*");
        if (!isBotAdmins) return reply("*❌ The bot needs admin rights to execute this command.*");
        
        await client.groupSettingUpdate(from, 'not_announcement');
        
        const response = { text: '*✅ The group has been opened by ' + pushname + '.* 🔇' };
        await client.sendMessage(from, response, { 'quoted': message });
    } catch (error) {
        console.log(error);
        reply("❌ *Error occurred !!*\n\n" + error);
    }
});

// Commande pour verrouiller les paramètres du groupe (seuls les admins peuvent modifier)
cmd({
    pattern: "lockgsettings",
    react: "🔒",
    alias: ["lockgs"],
    desc: "Restrict group settings so only admins can edit group info.",
    category: "group",
    use: ".lockgs",
    filename: __filename
}, async (client, message, context, { from, isGroup, sender, isOwner, isBotAdmins, isAdmins, reply, pushname }) => {
    try {
        if (!isGroup) return reply("*❌ This command can only be used in groups.*");
        if (!isOwner && !isAdmins) return reply("*⚠️ Only group admins or the bot owner can use this command.*");
        if (!isBotAdmins) return reply("*❌ The bot needs admin rights to execute this command.*");
        
        await client.groupSettingUpdate(from, 'locked');
        
        const response = { text: '*✅ Group settings locked by ' + pushname + '.* 🔒' };
        await client.sendMessage(from, response, { 'quoted': message });
    } catch (error) {
        console.log(error);
        reply("❌ *Error occurred !!*\n\n" + error);
    }
});

// Commande pour déverrouiller les paramètres du groupe (tous peuvent modifier)
cmd({
    pattern: "unlockgsettings",
    react: "🔓",
    alias: ["unlockgs"],
    desc: "Allow all members to edit group info.",
    category: "group",
    use: ".unlockgs",
    filename: __filename
}, async (client, message, context, { from, isGroup, sender, isOwner, isBotAdmins, isAdmins, reply, pushname }) => {
    try {
        if (!isGroup) return reply("*❌ This command can only be used in groups.*");
        if (!isOwner && !isAdmins) return reply("*⚠️ Only group admins or the bot owner can use this command.*");
        if (!isBotAdmins) return reply("*❌ The bot needs admin rights to execute this command.*");
        
        await client.groupSettingUpdate(from, 'unlocked');
        
        const response = { text: '*✅ Group settings unlocked by ' + pushname + '.* 🔓' };
        await client.sendMessage(from, response, { 'quoted': message });
    } catch (error) {
        console.log(error);
        reply("❌ *Error occurred !!*\n\n" + error);
    }
});

// Commande pour que le bot quitte le groupe
const leaveCommand = {
    pattern: "leave",
    react: "🔓",
    alias: ["left", "f-left", "f_leave", "f_left"],
    desc: "To leave from the group",
    category: "group",
    use: ".leave",
    filename: __filename
};

cmd(leaveCommand, async (client, message, context, { from, isGroup, isOwner, reply }) => {
    try {
        const responseMsg = (await fetchJson('https://raw.githubusercontent.com/SILENTLOVER40/SILENT-SOBX-MD-DATA/refs/heads/main/DATABASE/mreply.json')).replyMsg;
        
        if (!isGroup) return reply("*❌ This command can only be used in a group*");
        if (!isOwner) return reply("*❌ Only the bot owner can use this command!*");
        
        await client.sendMessage(from, { text: "*Good Bye All* 👋🏻" }, { 'quoted': message });
        await client.groupLeave(from);
    } catch (error) {
        await client.sendMessage(from, { react: { text: '❌', key: message.key } });
        console.log(error);
        reply("❌ *An error occurred !!*\n\n" + error);
    }
});

// Commande pour changer le nom du groupe
cmd({
    pattern: "updategname",
    react: "🔓",
    alias: ["upgname", "gname"],
    desc: "Change the group name.",
    category: "group",
    use: ".updategname <new name>",
    filename: __filename
}, async (client, message, context, { from, isGroup, sender, isAdmins, isBotAdmins, reply, groupName, q }) => {
    try {
        const responseMsg = (await fetchJson('https://raw.githubusercontent.com/SILENTLOVER40/SILENT-SOBX-MD-DATA/refs/heads/main/DATABASE/mreply.json')).replyMsg;
        
        if (!isGroup) return reply("*❌ This command can only be used in groups.*");
        if (!isAdmins) return reply("*⚠️ Only group admins or the bot owner can use this command.*");
        if (!isBotAdmins) return reply("*❌ The bot needs admin rights to execute this command.*");
        if (!q) return reply("*⚠️ Please provide the new group name.*");
        
        await client.groupUpdateSubject(from, q);
        
        const response = { text: '*✅ Group name updated to: ' + q + '*' };
        await client.sendMessage(from, response, { 'quoted': message });
    } catch (error) {
        await client.sendMessage(from, { react: { text: '❌', key: message.key } });
        console.log(error);
        reply("❌ *Error Accurated !!*\n\n" + error);
    }
});

// Commande pour changer la description du groupe
cmd({
    pattern: "updategdesc",
    react: "🔓",
    alias: ["upgdesc", "gdesc"],
    desc: "Change the group description.",
    category: "group",
    use: ".updategdesc <new description>",
    filename: __filename
}, async (client, message, context, { from, isGroup, sender, isAdmins, isBotAdmins, reply, q }) => {
    try {
        const responseMsg = (await fetchJson('https://raw.githubusercontent.com/SILENTLOVER40/SILENT-SOBX-MD-DATA/refs/heads/main/DATABASE/mreply.json')).replyMsg;
        
        if (!isGroup) return reply("*❌ This command can only be used in groups.*");
        if (!isAdmins) return reply("*⚠️ Only group admins or the bot owner can use this command.*");
        if (!isBotAdmins) return reply("*⚠️ I need to be an admin to execute this command.*");
        if (!q) return reply("*⚠️ Please provide the new group description.*");
        
        await client.groupUpdateDescription(from, q);
        
        const response = { text: '*✅ Group description updated to: ' + q + '*' };
        await client.sendMessage(from, response, { 'quoted': message });
    } catch (error) {
        await client.sendMessage(from, { react: { text: '❌', key: message.key } });
        console.log(error);
        reply("❌ *Error Accurated !!*\n\n" + error);
    }
});

// Commande pour rejoindre un groupe via un lien d'invitation
cmd({
    pattern: "join",
    react: "📬",
    alias: ["joinme", "grouplink"],
    desc: "To Join a Group from Invite link",
    category: "group",
    use: ".join < Group Link >",
    filename: __filename
}, async (client, message, context, { from, isCmd, body, command, args, q, isGroup, sender, senderNumber, isOwner, isCreator, isDev, reply }) => {
    try {
        const responseMsg = (await fetchJson('https://raw.githubusercontent.com/SILENTLOVER40/SILENT-SOBX-MD-DATA/refs/heads/main/DATABASE/mreply.json')).replyMsg;
        
        if (!isCreator && !isDev && !isOwner) return reply("*⚠️ Only the Owner can use this command*");
        if (!q) return reply("*⚠️ Please provide the Group Link* 🖇️");
        
        let inviteCode = args[0].split('https://chat.whatsapp.com/')[1];
        await client.groupAcceptInvite(inviteCode);
        
        const options = { 'quoted': message };
        await client.sendMessage(from, { text: "✅ *Your request to join the group has been sent*" }, options);
        await client.sendMessage(from, { text: "Successfully joined!" }, options);
    } catch (error) {
        await client.sendMessage(from, { react: { text: '❌', key: message.key } });
        console.log(error);
        reply("❌ *Error Accurated !!*\n\n" + error);
    }
});

// Commande pour obtenir le lien d'invitation du groupe
cmd({
    pattern: "invite",
    react: "🖇️",
    alias: ["glink", "grouplink"],
    desc: "To Get the Group Invite link",
    category: "group",
    use: ".invite",
    filename: __filename
}, async (client, message, context, { from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isCreator, isDev, isAdmins, reply }) => {
    try {
        const responseMsg = (await fetchJson('https://raw.githubusercontent.com/SILENTLOVER40/SILENT-SOBX-MD-DATA/refs/heads/main/DATABASE/mreply.json')).replyMsg;
        
        if (!isGroup) return reply(responseMsg.only_gp);
        if (!isOwner && !isDev && !isAdmins) return reply("*⚠️ Only group admins or the bot owner can use this command.*");
        if (!isBotAdmins) return reply("*❌ The bot needs admin rights to generate the invite link.*");
        
        const inviteCode = await client.groupInviteCode(from);
        const inviteLink = { text: 'https://chat.whatsapp.com/' + inviteCode };
        const options = { 'quoted': message };
        
        await client.sendMessage(from, inviteLink, options);
    } catch (error) {
        await client.sendMessage(from, { react: { text: '❌', key: message.key } });
        console.log(error);
        reply("❌ *Error Accurated !!*\n\n" + error);
    }
});

// Commande pour révoquer (réinitialiser) le lien d'invitation du groupe
cmd({
    pattern: "revoke",
    react: "🖇️",
    alias: ["revokelink", "resetglink", "revokegrouplink"],
    desc: "To Reset the group link",
    category: "group",
    use: ".revoke",
    filename: __filename
}, async (client, message, context, { from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isCreator, isDev, isAdmins, reply }) => {
    try {
        const responseMsg = (await fetchJson('https://raw.githubusercontent.com/SILENTLOVER40/SILENT-SOBX-MD-DATA/refs/heads/main/DATABASE/mreply.json')).replyMsg;
        
        if (!isGroup) return reply(responseMsg.only_gp);
        if (!isOwner && !isAdmins) return reply("*❌ Only admins and the owner can reset the group link.*");
        if (!isBotAdmins) return reply("*❌ The bot needs admin rights to reset the group link.*");
        
        await client.groupRevokeInvite(from);
        
        const options = { 'quoted': message };
        await client.sendMessage(from, { text: "Group link has been reset successfully!" }, options);
    } catch (error) {
        await client.sendMessage(from, { react: { text: '❌', key: message.key } });
        console.log(error);
        reply("❌ *Error Accurated !!*\n\n" + error);
    }
});

// Commande pour taguer tous les membres
cmd({
    pattern: "tagall",
    react: "🔊",
    alias: ["f_tagall"],
    desc: "To Tag all Members",
    category: "group",
    use: ".tagall",
    filename: __filename
}, async (client, message, context, { from, l, quoted, body, isCmd, command, mentionByTag, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isCreator, isDev, isAdmins, reply }) => {
    try {
        const responseMsg = (await fetchJson('https://raw.githubusercontent.com/SILENTLOVER40/SILENT-SOBX-MD-DATA/refs/heads/main/DATABASE/mreply.json')).replyMsg;
        
        if (!isGroup) return reply(responseMsg.only_gp);
        if (!isAdmins) {
            const options = { 'quoted': message };
            if (!isDev) return reply(responseMsg.you_adm), options;
        }
        if (!isBotAdmins) return reply(responseMsg.need_admin);
        
        let tagMessage = "💱 *HI ALL ! GIVE YOUR ATTENTION PLEASE*\n \n";
        
        for (let participant of participants) {
            tagMessage += "😻 @" + participant.id.split('@')[0] + '\n';
        }
        
        const options = { 'quoted': message };
        client.sendMessage(from, {
            text: tagMessage,
            mentions: participants.map(p => p.id)
        }, options);
    } catch (error) {
        await client.sendMessage(from, { react: { text: '❌', key: message.key } });
        console.log(error);
        reply("❌ *Error occurred !*\n\n" + error);
    }
});

// Commande pour taguer avec message caché
cmd({
    pattern: "hidetag",
    react: "🔊",
    alias: ["tag", "f_tag"],
    desc: "To Tag all Members for Message",
    category: "group",
    use: ".tag Hi",
    filename: __filename
}, async (client, message, context, { from, l, quoted, body, isCmd, command, mentionByTag, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isCreator, isDev, isAdmins, reply }) => {
    try {
        if (!isGroup) return reply("*❌ This command can only be used in groups.*");
        if (!isAdmins && !isOwner) return reply("*⚠️ Only group admins or the bot owner can use this command.*");
        if (!isBotAdmins) return reply("*❌ The bot needs admin rights to execute this command.*");
        if (!q) return reply("*Please add a Message* ℹ️");
        
        let tagText = '' + q;
        const options = { 'quoted': message };
        
        await client.sendMessage(from, {
            text: tagText,
            mentions: participants.map(p => p.id)
        }, options);
    } catch (error) {
        await client.sendMessage(from, { react: { text: '❌', key: message.key } });
        console.log(error);
        reply("❌ *Error Accurated !!*\n\n" + error);
    }
});

// Commande pour taguer avec message cité
cmd({
    pattern: "taggp",
    react: "🔊",
    alias: ["f_taggp", "f_tag"],
    desc: "To Tag all Members for Message",
    category: "group",
    use: ".tag Hi",
    filename: __filename
}, async (client, message, context, { from, l, quoted, body, isCmd, command, mentionByTag, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isCreator, isDev, isAdmins, reply }) => {
    try {
        if (!context.quoted) return reply("*Please mention a message* ℹ️");
        if (!q) return reply("*Please add a Group Jid* ℹ️");
        
        let quotedText = '' + context.quoted.msg;
        const options = { 'quoted': message };
        
        client.sendMessage(q, {
            text: quotedText,
            mentions: participants.map(p => p.id)
        }, options);
    } catch (error) {
        await client.sendMessage(from, { react: { text: '❌', key: message.key } });
        console.log(error);
        reply("❌ *Error Accurated !!*\n\n" + error);
    }
});