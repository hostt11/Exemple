/**
 * Commande Vérificateur de Site
 * Vérifie si un site est en ligne
 * Utilisation: .site <url>
 */

const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "site",
    alias: ["check", "sitecheck", "uptime"],
    desc: "Check if a website is online",
    category: "tools",
    use: "<url>",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        if (!q) {
            return reply("❌ *Usage:*\n.site <url>\n\n*Examples:*\n.site google.com\n.site https://example.com\n.site github.com");
        }

        await reply(`🔍 *Checking site: ${q}...*`);

        const url = `https://kerm-apis.vercel.app/tools/sitecheck?url=${encodeURIComponent(q)}`;
        const res = await axios.get(url, { timeout: 15000 });

        if (!res.data || !res.data.status) {
            return reply("❌ Site check service error");
        }

        const data = res.data.result;

        // Déterminer l'emoji et le message
        let emoji = '❓';
        let statusText = '';
        
        if (data.online) {
            emoji = '✅';
            statusText = 'ONLINE';
        } else {
            emoji = '❌';
            statusText = 'OFFLINE';
        }

        let msg = `🌐 *SITE STATUS* 🌐\n\n`;
        msg += `🔗 *URL:* ${data.url}\n`;
        msg += `🌍 *Domain:* ${data.domain}\n`;
        msg += `${emoji} *Status:* ${statusText}\n`;
        
        if (data.statusCode) {
            msg += `📟 *HTTP Code:* ${data.statusCode}\n`;
        }
        
        if (data.statusMessage) {
            msg += `📝 *Message:* ${data.statusMessage}\n`;
        }
        
        if (data.responseTime) {
            msg += `⏱️ *Response Time:* ${data.responseTime}ms\n`;
        }
        
        if (data.server && data.server !== 'Unknown') {
            msg += `🖥️ *Server:* ${data.server}\n`;
        }
        
        if (data.contentType && data.contentType !== 'Unknown') {
            msg += `📄 *Content Type:* ${data.contentType}\n`;
        }
        
        if (data.poweredBy) {
            msg += `⚡ *Powered By:* ${data.poweredBy}\n`;
        }
        
        if (data.error) {
            msg += `\n⚠️ *Error:* ${data.error}`;
        }

        await reply(msg);

    } catch (error) {
        console.error("Site check command error:", error);
        reply(`❌ Error: ${error.message || "Failed to check site"}`);
    }
});