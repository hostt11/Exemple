const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "meteo",
    alias: ["weather", "météo", "temp"],
    desc: "Météo en direct par ville",
    category: "tools",
    use: "<ville>",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    if (!q) return reply("❌ Exemple: .meteo Paris");
    
    try {
        const url = `https://kerm-apis.vercel.app/tools/weather?q=${encodeURIComponent(q)}`;
        const res = await axios.get(url, { timeout: 5000 }); // Timeout 5 secondes
        
        if (!res.data.status) return reply("❌ Erreur API");
        
        const data = res.data.result;
        
        let msg = `🌍 *Météo: ${data.ville}*`;
        if (data.pays) msg += `, ${data.pays}`;
        msg += `\n\n`;
        msg += `${data.icon} *Température:* ${data.temperature}\n`;
        msg += `🌬️ *Vent:* ${data.vent}\n`;
        msg += `☁️ *Conditions:* ${data.conditions}\n`;
        if (data.humidite) msg += `💧 *Humidité:* ${data.humidite}\n`;
        msg += `\n🕐 *Mis à jour:* ${data.heure || 'maintenant'}`;
        
        await reply(msg);
        
    } catch (e) {
        console.error("Weather command error:", e.message);
        reply("❌ Ville non trouvée ou service indisponible");
    }
});