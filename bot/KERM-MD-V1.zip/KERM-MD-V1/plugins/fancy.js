/**
 * Commande Fancy Text - Transforme le texte en styles stylés avec sélection
 * Utilisation: .fancy <texte> puis choisir le numéro du style
 */

const axios = require("axios");
const { cmd } = require("../command");

// Stockage temporaire des styles générés (à cleaner après usage)
const fancyCache = new Map();

cmd({
    pattern: "fancy",
    alias: ["style", "stylish", "fancytext"],
    desc: "Transform your text into fancy styles with selection",
    category: "tools",
    use: "<text>",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        // Vérifier si l'utilisateur a fourni un texte
        if (!q) {
            return reply("❌ *Usage:*\n.fancy <text>\n\n*Examples:*\n.fancy Hello\n.fancy Kerm\n\nThen reply with the style number to get your fancy text.");
        }

        // Générer les styles
        await reply(`🔄 *Generating 20 fancy styles for "${q}"...*`);

        const url = `https://kerm-apis.vercel.app/tools/fancy?text=${encodeURIComponent(q)}`;
        const res = await axios.get(url, { timeout: 10000 });

        if (!res.data || !res.data.status) {
            return reply("❌ Fancy text service error");
        }

        const data = res.data.result;
        
        // Stocker les styles dans le cache avec l'ID du message
        const cacheId = m.key.id;
        fancyCache.set(cacheId, {
            styles: data.styles,
            original: data.original,
            timestamp: Date.now()
        });

        // Nettoyer l'ancien cache (plus de 5 minutes)
        for (const [id, value] of fancyCache.entries()) {
            if (Date.now() - value.timestamp > 300000) {
                fancyCache.delete(id);
            }
        }

        // Construire le message avec les styles numérotés
        let msg = `✨ *FANCY TEXT STYLES* ✨\n\n`;
        msg += `📝 *Original:* ${data.original}\n`;
        msg += `🔢 *Styles:* ${data.count}\n\n`;

        // Ajouter tous les styles avec des numéros
        const styleList = Object.entries(data.styles);
        const styleEmojis = {
            bold: "🔹", italic: "🔸", bolditalic: "🔹", script: "📝", 
            doublestruck: "🔢", fraktur: "⚜️", sansserif: "📐", circled: "⭕",
            squared: "🔲", regional: "🇺🇳", superscript: "⬆️", subscript: "⬇️",
            gothic: "🕍", monospace: "💻", smallcaps: "🔠", inverted: "🔄",
            bubble: "🫧", square: "⬛", parenthesized: "()", fullwidth: "📏"
        };

        styleList.forEach(([style, text], index) => {
            const number = (index + 1).toString().padStart(2, '0');
            const emoji = styleEmojis[style] || "•";
            msg += `${number}. ${emoji} ${text}\n`;
        });

        msg += `\n📌 *Reply with the style number (1-20) to get your text!*`;

        await reply(msg);

    } catch (error) {
        console.error("Fancy command error:", error);
        reply(`❌ Error: ${error.message || "Failed to generate fancy text"}`);
    }
});

// Gestionnaire pour les réponses (sélection de style)
cmd({
    pattern: "fancy",
    alias: ["style", "stylish"],
    desc: "Select a fancy style by number",
    category: "tools",
    filename: __filename,
    on: "text"
}, async (conn, mek, m, { from, reply, isQuoted }) => {
    try {
        // Vérifier si c'est une réponse à un message fancy
        if (!m.quoted) return;
        
        const quotedMsg = m.quoted;
        const quotedText = quotedMsg.message?.conversation || 
                          quotedMsg.message?.extendedTextMessage?.text || '';
        
        // Vérifier si le message cité contient "FANCY TEXT STYLES"
        if (!quotedText.includes("FANCY TEXT STYLES")) return;

        // Récupérer le numéro choisi
        const choice = parseInt(q);
        if (isNaN(choice) || choice < 1 || choice > 20) {
            return reply("❌ Please reply with a valid number between 1 and 20");
        }

        // Récupérer les styles du cache
        const cacheId = quotedMsg.key.id;
        const cached = fancyCache.get(cacheId);
        
        if (!cached) {
            return reply("❌ Session expired. Please run .fancy <text> again.");
        }

        // Obtenir le style correspondant au numéro
        const styleList = Object.entries(cached.styles);
        const selected = styleList[choice - 1];
        
        if (!selected) {
            return reply("❌ Invalid style number");
        }

        const [styleName, styledText] = selected;

        // Répondre avec uniquement le texte stylé
        await reply(`✨ *Your fancy text:*\n\n${styledText}`);

        // Nettoyer le cache après utilisation
        fancyCache.delete(cacheId);

    } catch (error) {
        console.error("Fancy selection error:", error);
        reply(`❌ Error: ${error.message || "Failed to apply style"}`);
    }
});