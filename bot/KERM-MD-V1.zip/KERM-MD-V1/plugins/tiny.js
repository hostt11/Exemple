/*
_  ______   _____ _____ _____ _   _
| |/ / ___| |_   _| ____/___ | | | |
| ' / |  _    | | |  _|| |   | |_| |
| . \ |_| |   | | | |__| |___|  _  |
|_|\_\____|   |_| |_____\____|_| |_|

ANYWAY, YOU MUST GIVE CREDIT TO MY CODE WHEN COPY IT
CONTACT ME HERE +237656520674
YT: KermHackTools
Github: Kgtech-cmr
*/

const { cmd } = require("../command");
const fetch = require("node-fetch");
const axios = require("axios");

cmd({
    pattern: "tiny",
    react: "🫧",
    desc: "Makes URL tiny.",
    category: "converter",
    use: "<url>",
    filename: __filename,
},
async (conn, mek, m, { from, quoted, isOwner, isAdmins, reply, args }) => {
    console.log("Command tiny triggered");

    if (!args[0]) {
        console.log("No URL provided");
        return reply("❌ Provide me a link to shorten");
    }

    try {
        const link = args[0];
        
        // Validation basique de l'URL
        if (!link.match(/^https?:\/\//)) {
            return reply("❌ Please provide a valid URL starting with http:// or https://");
        }
        
        console.log("URL to shorten:", link);
        
        // Utilisation de ta nouvelle API Kerm
        const encodedLink = encodeURIComponent(link);
        const apiUrl = `https://kerm-apis.vercel.app/tools/tiny?url=${encodedLink}`;
        
        console.log("API URL:", apiUrl);
        
        const response = await axios.get(apiUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0',
                'Accept': 'application/json',
            }
        });

        console.log("API Response:", response.data);

        // Vérification de la structure de ta réponse
        if (!response.data || !response.data.status || !response.data.result) {
            return reply("❌ Invalid response from API. Please try again.");
        }

        const shortenedUrl = response.data.result;

        console.log("Shortened URL:", shortenedUrl);
        
        // Message de réponse formaté
        const replyMessage = `*🔗 URL Shortcut with Success!*\n\n` +
                            `*📌 URL Original:*\n${link}\n\n` +
                            `*🔗 URL Shortened:*\n${shortenedUrl}\n\n` +
                            `_Powered by Kerm API_`;
        
        return reply(replyMessage);
        
    } catch (e) {
        console.error("Error shortening URL:", e);
        
        // Gestion détaillée des erreurs
        let errorMessage = "❌ An error occurred while shortening the URL.\n\n";
        
        if (e.response) {
            // L'API a répondu avec une erreur
            console.error("API Error Response:", e.response.data);
            errorMessage += `API Error: ${e.response.status} - ${e.response.statusText}`;
        } else if (e.request) {
            // Pas de réponse de l'API
            errorMessage += "No response received from API. Server might be down.";
        } else {
            // Erreur lors de la configuration de la requête
            errorMessage += e.message;
        }
        
        return reply(errorMessage);
    }
});