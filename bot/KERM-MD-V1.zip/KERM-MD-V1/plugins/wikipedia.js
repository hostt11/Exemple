/**
 * Commande Wikipedia
 */

const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "wiki",
    alias: ["wikipedia"],
    desc: "Get Wikipedia article summary",
    category: "search",
    use: "<search term>",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        if (!q) {
            return reply("❌ *Usage:*\n.wiki <search term>\n\n*Example:*\n.wiki France");
        }

        await reply(`🔍 *Searching Wikipedia for:* ${q}`);

        // Rechercher l'article
        const searchUrl = `https://kerm-apis.vercel.app/search/wikipedia?q=${encodeURIComponent(q)}`;
        const searchRes = await axios.get(searchUrl, { timeout: 10000 });

        if (!searchRes.data?.status || searchRes.data.result.total === 0) {
            return reply(`❌ No results found for "${q}"`);
        }

        const firstResult = searchRes.data.result.results[0];

        // Récupérer l'article
        const articleUrl = `https://kerm-apis.vercel.app/wikipedia/article?title=${encodeURIComponent(firstResult.title)}`;
        const articleRes = await axios.get(articleUrl, { timeout: 10000 });

        if (!articleRes.data?.status) {
            return reply(`❌ Could not load article: ${firstResult.title}`);
        }

        const article = articleRes.data.result;
        
        // Tronquer l'extrait
        let extract = article.extract;
        if (extract.length > 3000) {
            extract = extract.substring(0, 3000) + "...\n\n_[Article truncated]_";
        }

        let msg = `📚 *${article.title}*\n\n`;
        msg += `${extract}\n\n`;
        msg += `🔗 ${article.url}`;

        await reply(msg);

    } catch (error) {
        console.error("Wikipedia error:", error);
        reply(`❌ Error: ${error.message}`);
    }
});