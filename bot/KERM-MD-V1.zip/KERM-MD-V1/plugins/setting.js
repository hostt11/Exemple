/*
_  ______   _____ _____ _____ _   _
| |/ / ___| |_   _| ____/___ | | | |
| ' / |  _    | | |  _|| |   | |_| |
| . \ |_| |   | | | |__| |___|  _  |
|_|\_\____|   |_| |_____\____|_| |_|

ANYWAY, YOU MUST GIVE CREDIT TO MY CODE WHEN COPY IT
CONTACT ME HERE +237656520674
YT: KermHackTools
Github: Kgtech-cmr
*/

const config = require('../config')
const { cmd, commands } = require('../command')
const os = require("os")

// Read prefix dynamically from config
const prefix = config.PREFIX || config.prefix || "."

cmd({
    pattern: "settings",
    alias: ["setting"],
    react: "⚙️",
    desc: "settings the bot",
    category: "owner"
},
async (conn, mek, m, { 
    from, quoted, body, isCmd, command, args, q, 
    isGroup, sender, senderNumber, botNumber2, 
    botNumber, pushname, isMe, isOwner, 
    groupMetadata, groupName, participants, 
    groupAdmins, isBotAdmins, isAdmins, reply 
}) => {

    try {

        if (!isOwner) {
            return reply("*⛔️You are not the owner.*")
        }

        let desc = `
        
╭┈┉┉⚡⚙  MD BOT SETTINGS ⚙⚡┉┉┈
┇
┇💼 Work Mode : 𝙿𝚄𝙱𝙻𝙸𝙲🌎/𝙿𝚁𝙸𝚅𝙰𝚃𝙴
┇🔊 Auto Voice : ♻ 𝙾𝙽/𝙾𝙵𝙵
┇📝 Auto Status : ♻ 𝙾𝙽/𝙾𝙵𝙵
┇⌨ Auto Typing : ♻ 𝙾𝙽/𝙾𝙵𝙵
┇🛠 Auto Read Command : ♻ 𝙾𝙽/𝙾𝙵𝙵
╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈

   🔗  CUSTOMIZE YOUR SETTINGS ⤵️
   
↪ʀᴇᴘʟʏ ᴡɪᴛʜ ᴛʜᴇ ɴᴜᴍʙᴇʀ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ sᴇʟᴇᴄᴛ

    🔧 OPTIONS MENU 🔧

┣━ WORK MODE ⤵️
┃   ┣ 1.1 🔹 Public Work
┃   ┣ 1.2 🔹 Private Work

┣━ AUTO VOICE ⤵️
┃   ┣ 2.1 🔊 Auto Voice On
┃   ┗ 2.2 🔕 Auto Voice Off

┣━ AUTO STATUS SEEN ⤵️
┃   ┣ 3.1 👁‍🗨 Auto Read Status On
┃   ┗ 3.2 👁❌ Auto Read Status Off

┣━ AUTO TYPING ⤵️
┃   ┣ 4.1 📝 Activate Auto Typing
┃   ┗ 4.2 📝❌ Deactivate Auto Typing

┣━ AUTO STICKER ⤵️
┃   ┣ 5.1 🎉 Activate Auto Sticker
┃   ┗ 5.2 🎉❌ Deactivate Auto Sticker

┣━ ANTI BAD ⤵️
┃   ┣ 6.1 🚫 Activate Anti Bad
┃   ┗ 6.2 🚫❌ Deactivate Anti Bad

┣━ AUTO REPLY ⤵️
┃   ┣ 7.1 💬 Activate Auto Reply
┃   ┗ 7.2 💬❌ Deactivate Auto Reply

┣━ AUTO RECORDING ⤵️
┃   ┣ 8.1 🎥 Activate Auto Recording
┃   ┗ 8.2 🎥❌ Deactivate Auto Recording

┣━ ALWAYS ONLINE ⤵️
┃   ┣ 9.1 🌐 Activate Always Online
┃   ┗ 9.2 🌐❌ Deactivate Always Online

┣━ ANTI LINK ⤵️
┃   ┣ 10.1 🔗 Activate Anti Link
┃   ┗ 10.2 🔗❌ Deactivate Anti Link
┗━━━━━━━━━━━━━━━━━━━━━`;

        const sentMsg = await conn.sendMessage(from, { 
            image: { url: "https://files.catbox.moe/1e05nm.jpeg" },
            caption: desc
        }, { quoted: mek });

        const messageHandler = async (msgUpdate) => {

            const msg = msgUpdate.messages[0];
            if (!msg.message || !msg.message.extendedTextMessage) return;

            const selectedOption = msg.message.extendedTextMessage.text.trim();

            if (
                msg.message.extendedTextMessage.contextInfo &&
                msg.message.extendedTextMessage.contextInfo.stanzaId === sentMsg.key.id
            ) {

                switch (selectedOption) {

                    case '1.1': reply(`${prefix}mode public`); break;
                    case '1.2': reply(`${prefix}mode private`); break;

                    case '2.1': reply(`${prefix}autovoice on`); break;
                    case '2.2': reply(`${prefix}autovoice off`); break;

                    case '3.1': reply(`${prefix}autostatusview on`); break;
                    case '3.2': reply(`${prefix}autostatusview off`); break;

                    case '4.1': reply(`${prefix}autotyping on`); break;
                    case '4.2': reply(`${prefix}autotyping off`); break;

                    case '5.1': reply(`${prefix}autosticker on`); break;
                    case '5.2': reply(`${prefix}autosticker off`); break;

                    case '6.1': reply(`${prefix}antibad on`); break;
                    case '6.2': reply(`${prefix}antibad off`); break;

                    case '7.1': reply(`${prefix}autoreply on`); break;
                    case '7.2': reply(`${prefix}autoreply off`); break;

                    case '8.1': reply(`${prefix}autorecording on`); break;
                    case '8.2': reply(`${prefix}autorecording off`); break;

                    case '9.1': reply(`${prefix}alwaysonline on`); break;
                    case '9.2': reply(`${prefix}alwaysonline off`); break;

                    case '10.1': reply(`${prefix}antilink on`); break;
                    case '10.2': reply(`${prefix}antilink off`); break;

                    default:
                        reply("Invalid option. Please select a valid option 🔴");
                }

                // Remove listener after one valid interaction
                conn.ev.off('messages.upsert', messageHandler);
            }
        };

        conn.ev.on('messages.upsert', messageHandler);

    } catch (e) {
        console.error(e);
        await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
        reply('An error occurred while processing your request.');
    }

});