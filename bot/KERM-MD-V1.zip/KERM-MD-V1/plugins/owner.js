const { cmd } = require('../command');

cmd({
  pattern: "owner",
  react: "👑", 
  alias: ["kerm"],
  desc: "Get owner number",
  category: "main",
  filename: __filename
}, async (conn, mek, m, { from }) => {
  try {
    // Propriétaire unique
    const owner = { 
      number: '+237659535227', 
      name: '༒𝐋𝐎𝐑𝐃 𝐊𝐄𝐑𝐌༒', 
      organization: 'KG TEAM' 
    };

    // Créer la vCard
    const vcard = `BEGIN:VCARD\n` +
      `VERSION:3.0\n` +
      `FN:${owner.name}\n` +
      `ORG:${owner.organization}\n` +
      `TEL;type=CELL;type=VOICE;waid=${owner.number.replace('+', '')}:${owner.number}\n` +
      `END:VCARD`;

    // Envoyer uniquement la vCard
    await conn.sendMessage(from, { 
      contacts: {
        displayName: owner.name,
        contacts: [{ vcard }]
      }
    }, { quoted: mek });
    
  } catch (error) {
    console.error(error);
    await conn.sendMessage(from, {
      text: '❌ Erreur lors de l\'envoi du contact.'
    }, { quoted: mek });
  }
});