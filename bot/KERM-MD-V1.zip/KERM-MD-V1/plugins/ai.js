/*
_  ______   _____ _____ _____ _   _
| |/ / ___| |_   _| ____/___ | | | |
| ' / |  _    | | |  _|| |   | |_| |
| . \ |_| |   | | | |__| |___|  _  |
|_|\_\____|   |_| |_____\____|_| |_|

ANYWAY, YOU MUST GIVE CREDIT TO MY CODE WHEN COPY IT
CONTACT ME HERE +237656520674
YT: KermHackTools
Github: Kgtech-cmr
*/

const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "gpt",
    alias: ["ai"],
    desc: "Interact with ChatGPT using the Kerm API.",
    category: "ai",
    react: "🤖",
    use: ".gpt <question>",
    filename: __filename
},
async (conn, mek, m, { from, q, reply }) => {
    try {

        if (!q) {
            return reply("⚠️ Please provide a query.\n\nExample:\n.gpt What is AI?");
        }

        const url = `https://kerm-apis.vercel.app/ai?q=${encodeURIComponent(q)}`;

        const { data } = await axios.get(url, {
            headers: {
                "User-Agent": "Mozilla/5.0",
                "Accept": "application/json"
            }
        });

        if (!data || data.status !== true) {
            return reply("❌ API returned an invalid response.");
        }

        const gptResponse = data.result;

        const ALIVE_IMG = "https://files.catbox.moe/0buoao.jpeg";

        const message = `🤖 *ChatGPT Response*\n\n${gptResponse}\n\n_Powered by Kerm API_`;

        await conn.sendMessage(from, {
            image: { url: ALIVE_IMG },
            caption: message,
            contextInfo: {
                mentionedJid: [m.sender],
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "120363321386877609@newsletter",
                    newsletterName: "𝐊𝐄𝐑𝐌 𝐀𝐈",
                    serverMessageId: 143
                }
            }
        }, { quoted: mek });

    } catch (error) {

        console.log("GPT Command Error:", error.message);

        return reply(`❌ Error while contacting AI.\n\nDetails: ${error.message}`);
    }
});