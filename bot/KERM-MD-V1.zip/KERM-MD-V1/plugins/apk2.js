/**
 * Commande APK Downloader
 * Recherche une application Android et envoie l'APK
 * Utilisation: .apk <nom de l'app>
 */

const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "apk2",
    alias: ["app", "android", "apkdownload"],
    desc: "Search and download Android applications",
    category: "download",
    use: "<app name>",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        if (!q) {
            return reply("❌ *Usage:*\n.apk <app name>\n\n*Examples:*\n.apk whatsapp\n.apk instagram\n.apk spotify\n.apk telegram");
        }

        const searchingMsg = await reply(`🔍 *Searching for "${q}" on multiple sources...*`);

        const url = `https://kerm-apis.vercel.app/download/apk?q=${encodeURIComponent(q)}`;
        const res = await axios.get(url, { timeout: 20000 });

        if (!res.data || !res.data.status) {
            return reply("❌ No app found with that name. Try a different keyword.");
        }

        const data = res.data.result;
        const app = data.app;

        // Message d'information
        let infoMsg = `📱 *${app.name}*\n\n`;
        infoMsg += `📦 *Package:* \`${app.package}\`\n`;
        
        if (app.developer !== 'Unknown') {
            infoMsg += `👤 *Developer:* ${app.developer}\n`;
        }
        
        infoMsg += `🔖 *Version:* ${app.version}\n`;
        infoMsg += `📊 *Size:* ${app.size}\n`;
        
        if (app.downloads !== 'N/A' && app.downloads !== 'Unknown') {
            const downloads = typeof app.downloads === 'number' 
                ? app.downloads.toLocaleString() 
                : app.downloads;
            infoMsg += `⬇️ *Downloads:* ${downloads}\n`;
        }
        
        if (app.rating !== 'N/A' && app.rating !== 'Unknown') {
            infoMsg += `⭐ *Rating:* ${typeof app.rating === 'number' ? app.rating.toFixed(1) : app.rating}/5\n`;
        }

        infoMsg += `\n📌 *Found on:* ${data.total_found} source(s)`;
        infoMsg += `\n⏳ *Sending APK in a moment...*`;

        // Envoyer l'icône de l'application
        if (app.icon) {
            await conn.sendMessage(from, {
                image: { url: app.icon },
                caption: infoMsg
            }, { quoted: mek });
        } else {
            await reply(infoMsg);
        }

        // Supprimer le message de recherche
        if (searchingMsg) {
            await conn.sendMessage(from, { delete: searchingMsg.key });
        }

        // Attendre 2 secondes avant d'envoyer l'APK
        setTimeout(async () => {
            try {
                // Essayer d'envoyer l'APK directement
                await conn.sendMessage(from, {
                    document: { url: app.download_url },
                    mimetype: 'application/vnd.android.package-archive',
                    fileName: `${app.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_${app.version.replace(/[^a-z0-9.]/gi, '_')}.apk`,
                    caption: `✅ *${app.name}* APK ready to install!\n\nSize: ${app.size}`
                }, { quoted: mek });

            } catch (downloadError) {
                console.error('APK direct send failed:', downloadError);
                
                // Si l'envoi direct échoue, envoyer le lien
                await conn.sendMessage(from, {
                    text: `✅ *${app.name}* found!\n\nYou can download it directly from this link:\n${app.download_url}\n\nSize: ${app.size}`
                }, { quoted: mek });
            }
        }, 2000);

    } catch (error) {
        console.error("APK command error:", error);
        
        if (error.response?.status === 404) {
            reply("❌ App not found. Try with a different name.");
        } else {
            reply(`❌ Error: ${error.message || "Failed to fetch app information"}`);
        }
    }
});