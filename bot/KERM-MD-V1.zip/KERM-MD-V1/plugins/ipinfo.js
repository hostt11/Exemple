/**
 * Commande IP Info - Informations sur les adresses IP
 * Utilisation: .ip <adresse ip> ou .ip me
 * Nettoie automatiquement les entrées (enlève les points)
 */

const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "ip",
    alias: ["ipinfo", "ipaddress", "monip"],
    desc: "Get detailed information about an IP address",
    category: "tools",
    use: "<ip address> or 'me'",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        if (!q) {
            return reply("❌ *Usage:*\n.ip <ip_address>\n.ip me (for your own IP)\n\n*Examples:*\n.ip 8.8.8.8\n.ip me\n.ip 192.168.1.1");
        }

        await reply(`🔍 *Analyzing IP address...*`);

        const url = `https://kerm-apis.vercel.app/tools/ipinfo?ip=${encodeURIComponent(q)}`;
        const res = await axios.get(url, { timeout: 10000 });

        if (!res.data || !res.data.status) {
            return reply("❌ IP info service error");
        }

        const data = res.data.result;

        let msg = `🌐 *IP INFORMATION* 🌐\n\n`;
        msg += `📌 *IP:* ${data.ip}\n`;
        msg += `📍 *Location:* ${data.city}, ${data.region}, ${data.country} (${data.countryCode})\n`;
        msg += `📮 *Postal Code:* ${data.zip || 'N/A'}\n`;
        msg += `🌍 *Coordinates:* ${data.latitude}, ${data.longitude}\n`;
        msg += `⏰ *Timezone:* ${data.timezone}\n`;
        msg += `🏢 *ISP:* ${data.isp || 'N/A'}\n`;
        msg += `🏛️ *Organization:* ${data.organization || 'N/A'}\n`;
        msg += `🔢 *AS:* ${data.as || 'N/A'}`;

        await reply(msg);

    } catch (error) {
        console.error("IP Info command error:", error);
        
        if (error.message.includes("Invalid IP")) {
            reply("❌ Invalid IP address format. Please provide a valid IPv4 or IPv6 address.");
        } else {
            reply(`❌ Error: ${error.message || "Failed to get IP information"}`);
        }
    }
});