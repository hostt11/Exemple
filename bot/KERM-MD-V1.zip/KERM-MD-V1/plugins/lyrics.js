/**
 * Commande Lyrics - Paroles de chansons
 * Version avec formatage amélioré
 */

const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "lyrics",
    alias: ["paroles", "songlyrics", "lyric"],
    desc: "Get song lyrics by title or artist",
    category: "search",
    use: "<song title>",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        if (!q) {
            return reply("❌ *Usage:*\n.lyrics <song title>\n\n*Examples:*\n.lyrics shape of you\n.lyrics bohemian rhapsody");
        }

        await reply(`🔍 *Searching lyrics for:* ${q}`);

        const url = `https://kerm-apis.vercel.app/search/lyrics?q=${encodeURIComponent(q)}`;
        const res = await axios.get(url, { timeout: 15000 });

        if (!res.data || !res.data.status) {
            return reply("❌ Lyrics not found. Try with a different song.");
        }

        const data = res.data.result;

        // Formater les paroles
        let lyrics = data.lyrics
            .split('\n')
            .map(line => line.trim())
            .filter(line => line.length > 0)
            .join('\n');

        let msg = `┌─── ･ ｡ﾟ☆: *.☽ .* :☆ﾟ. ───┐\n`;
        msg += `        🎵 *LYRICS* 🎵\n`;
        msg += `└─── ･ ｡ﾟ☆: *.☽ .* :☆ﾟ. ───┘\n\n`;
        msg += `📌 *${data.title}*\n\n`;
        msg += `${lyrics}`;

        if (msg.length > 4000) {
            msg = msg.substring(0, 3500) + "\n\n_[Lyrics truncated...]_";
        }

        await reply(msg);

    } catch (error) {
        console.error("Lyrics command error:", error);
        reply(`❌ Error: ${error.message || "Failed to fetch lyrics"}`);
    }
});