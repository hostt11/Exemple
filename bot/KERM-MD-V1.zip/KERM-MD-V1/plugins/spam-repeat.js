/*
_  ______   _____ _____ _____ _   _
| |/ / ___| |_   _| ____/___ | | | |
| ' / |  _    | | |  _|| |   | |_| |
| . \ |_| |   | | | |__| |___|  _  |
|_|\_\____|   |_| |_____\____|_| |_|

ANYWAY, YOU MUST GIVE CREDIT TO MY CODE WHEN COPY IT
CONTACT ME HERE +237656520674
YT: KermHackTools
Github: Kgtech-cmr
*/

const { cmd } = require('../command');

// Commande spam pour répéter un message plusieurs fois (réservée au propriétaire)
cmd({
    'pattern': "spam",
    'desc': "Repeat a provided phrase a specified number of times (owner only).",
    'category': "admin",
    'react': "📣",
    'filename': __filename,
    'use': "<text>|<number>"
}, async (client, message, context, { from, args, isOwner, reply }) => {
    try {
        // Vérifier si l'utilisateur est le propriétaire du bot
        if (!isOwner) return reply("❌ You are not authorized to use this command.");
        
        // Joindre les arguments en une seule chaîne
        const fullInput = args.join(' ');
        
        // Vérifier si le format contient le séparateur "|"
        if (!fullInput.includes('|')) return reply("❌ Please use the format: .spam <text>|<number>");
        
        // Séparer le texte et le nombre
        const [text, countStr] = fullInput.split('|');
        const count = parseInt(countStr.trim());
        
        // Valider les entrées
        if (!text || isNaN(count) || count <= 0) {
            return reply("❌ Invalid format or number. Usage: .spam <text>|<number>");
        }
        
        // Limiter le nombre de répétitions à 30 maximum (réduit pour éviter le spam excessif)
        if (count > 30) return reply("❌ The maximum spam count allowed is 30.");
        
        // Envoyer une confirmation que le spam va commencer
        await reply(`📣 Spam started: ${count} messages will be sent...`);
        
        
        for (let i = 0; i < count; i++) {
            // Envoyer le message avec un numéro pour suivre la progression
            await client.sendMessage(from, { 
                text: `[${i+1}/${count}] ${text}` 
            });
            
           
            await new Promise(resolve => setTimeout(resolve, 500));
        }
        
        // Message de fin
        await reply(`✅ Spam completed! ${count} messages sent.`);
        
    } catch (error) {
        console.error("Spam command error:", error);
        reply("❌ An error occurred while processing the spam command.");
    }
});